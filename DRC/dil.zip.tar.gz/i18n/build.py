# -*- coding: utf-8 -*-
# Author: Aziz Köksal
# License: GPL2
