
#ifndef _GNUC_H
#define _GNUC_H 1

int memicmp(const char *s1, const char *s2, int n);
int stricmp(const char *s1, const char *s2);

#endif
